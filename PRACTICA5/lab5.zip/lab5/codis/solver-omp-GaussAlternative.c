#include "heat.h"
double relax_gauss (double *u, unsigned sizex, unsigned sizey)
{
	double unew, diff, sum=0.0;

    int howmany = omp_get_max_threads();
    char blockDepen[howmany][howmany];
    omp_lock_t lock;
    omp_init_lock(&lock);
    #pragma omp parallel
    #pragma omp single
	for(int blockid = 0; blockid < howmany; ++blockid){
        int startI = lowerb(blockid, howmany, sizex);
        int endI = upperb(blockid, howmany, sizey);

        for(int z = 0; z < howmany; z++){
            int startJ = lowerb(z, howmany, sizey);
            int endJ = upperb(z, howmany, sizey);
            #pragma omp task firstprivate(startI, endI, startJ, endJ) depend(out: blockDepen[blockid][z]) private(diff, unew) if(blockId == 0)
            #pragma omp task firstprivate(startI, endI, startJ, endJ) depend(in: blockDepen[blockid][max(0, z-1)]) depend(out: blockDepen[blockid][z]) private(diff, unew) if(blockId != 0)
            {
                double sumAux = 0.0;
                for(int i=max(1, startI); i<=endI; i++){
                    for(int j=max(1, startJ); j<=endJ; j++){
                        unew= 0.25 * ( u[ i*sizey	+ (j-1) ]+  // left
                        u[ i*sizey	+ (j+1) ]+  // right
                        u[ (i-1)*sizey	+ j     ]+  // top
                        u[ (i+1)*sizey	+ j     ]); // bottom
                        diff = unew - u[i*sizey+ j];
                        sumAux += diff * diff; 
                        u[i*sizey+j]=unew;
                    }
                }
                omp_set_lock(&lock);
                sum += sumAux;
                omp_unset_lock(&lock);
            }
        }
    }
	return sum;
}