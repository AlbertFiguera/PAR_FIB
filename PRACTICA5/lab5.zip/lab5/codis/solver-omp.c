#include "heat.h"

/*
 * Function to copy one matrix into another
 */

void copy_mat (double *u, double *v, unsigned sizex, unsigned sizey)
{
#pragma omp parallel for 
	for (int i=1; i<=sizex-2; i++)
		for (int j=1; j<=sizey-2; j++) 
			v[ i*sizey+j ] = u[ i*sizey+j ];
}

/*
 * Blocked Jacobi solver: one iteration step
 */
double relax_jacobi (double *u, double *utmp, unsigned sizex, unsigned sizey)
{
	double diff, sum = 0.0;
	int howmany = omp_get_max_threads();		 
	#pragma omp parallel for reduction(+:sum) private(diff)
	for (int blockid = 0; blockid < howmany; ++blockid) {
		int i_start = lowerb(blockid, howmany, sizex);
		int i_end = upperb(blockid, howmany, sizex);
		for (int i=max(1, i_start); i<= min(sizex-2, i_end); i++) {
			for (int j=1; j<= sizey-2; j++) {
				utmp[i*sizey+j]= 0.25 * ( u[ i*sizey     + (j-1) ]+  // left
						u[ i*sizey     + (j+1) ]+  // right
						u[ (i-1)*sizey + j     ]+  // top
						u[ (i+1)*sizey + j     ]); // bottom
				diff = utmp[i*sizey+j] - u[i*sizey + j];
				sum += diff * diff; 
			}
		}
	}
	return sum;
}

/*
 * Blocked Gauss-Seidel solver: one iteration step
 */


int mmax(int a, int b){
	return a < b ? b : a;
}

int mmin(int a, int b){
	return a > b ? b : a;
}

double relax_gauss (double *u, unsigned sizex, unsigned sizey)
{
	double unew, diff, sum=0.0;

	#pragma omp parallel
	#pragma omp single 
	{
		int howmany = omp_get_max_threads();
		for(int ii = 0; ii < howmany; ++ii) {
			for(int jj = 0; jj < howmany; ++jj){
				#pragma omp task depend(in: u[(ii-1)*sizey + jj]) depend(in: u[ii*sizey + jj-1]) depend(out: u[ii*sizey + jj])
				{
					for (int i=mmax(1, lowerb(ii,howmany,sizex)); i<= mmin(sizex-2, upperb(ii,howmany,sizex)); i++) {
						for (int j=mmax(1, lowerb(jj,howmany,sizey)); j<= mmin(sizey-2, upperb(jj,howmany,sizey)); j++) {
							unew= 0.25 * ( u[ i*sizey	+ (j-1) ]+  // left
									u[ i*sizey	+ (j+1) ]+  // right
									u[ (i-1)*sizey	+ j     ]+  // top
									u[ (i+1)*sizey	+ j     ]); // bottom
							diff = unew - u[i*sizey+ j];
							sum += diff * diff; 
							u[i*sizey+j]=unew;
						}
					}
				}
			}
		}
	}

	return sum;
}
